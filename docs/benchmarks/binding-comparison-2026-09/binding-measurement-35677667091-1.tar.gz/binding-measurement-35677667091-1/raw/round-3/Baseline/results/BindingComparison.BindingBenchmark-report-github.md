```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,118.19 μs** | **17.538 μs** | **43.350 μs** | **1,114.31 μs** |  **2.000** | **31.2500** |       **-** |  **584486 B** |
| Warm   | NodeRead           |   702.66 μs | 11.626 μs | 20.665 μs |   703.04 μs |  2.000 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,219.12 μs** | **12.975 μs** | **27.930 μs** | **1,206.77 μs** |  **2.000** | **31.2500** |       **-** |  **615478 B** |
| Warm   | ElementReadWrite   |   757.67 μs | 10.017 μs | 18.568 μs |   748.20 μs |  2.000 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,421.28 μs** | **20.699 μs** | **38.878 μs** | **1,420.77 μs** |  **2.000** | **41.0156** | **13.6719** |  **713594 B** |
| Warm   | DocumentLookup     | 1,092.95 μs | 17.553 μs | 31.652 μs | 1,085.48 μs |  3.625 | 23.4375 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **424.24 μs** |  **3.665 μs** |  **6.794 μs** |   **425.12 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    44.73 μs |  0.055 μs |  0.099 μs |    44.72 μs |  2.000 |       - |       - |     624 B |
