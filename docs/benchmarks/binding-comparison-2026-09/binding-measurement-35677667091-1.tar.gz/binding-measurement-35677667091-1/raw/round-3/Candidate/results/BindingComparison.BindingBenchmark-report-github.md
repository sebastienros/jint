```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error     | StdDev    | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|----------:|----------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **295.98 μs** |  **6.511 μs** | **11.741 μs** | **289.37 μs** |  **2.929** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 256.29 μs |  6.563 μs | 12.164 μs | 249.42 μs |  2.966 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **575.46 μs** |  **3.922 μs** |  **7.171 μs** | **576.03 μs** |  **2.000** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 534.55 μs |  2.068 μs |  3.729 μs | 536.31 μs |  2.000 | 12.6953 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **499.80 μs** | **36.241 μs** | **65.349 μs** | **509.19 μs** |  **4.000** |  **4.8828** |      **-** |   **94241 B** |
| Warm   | DocumentLookup     | 398.09 μs | 19.465 μs | 36.079 μs | 374.55 μs |  2.966 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **82.54 μs** |  **0.514 μs** |  **0.977 μs** |  **82.65 μs** |  **2.000** |  **3.4180** | **0.2441** |   **58457 B** |
| Warm   | InterpreterControl |  42.94 μs |  0.079 μs |  0.138 μs |  42.93 μs |  2.000 |       - |      - |     672 B |
