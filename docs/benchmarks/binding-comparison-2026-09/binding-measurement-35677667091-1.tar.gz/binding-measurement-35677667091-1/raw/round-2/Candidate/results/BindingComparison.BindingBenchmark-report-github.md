```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error     | StdDev    | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|----------:|----------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **290.32 μs** |  **1.086 μs** |  **1.958 μs** | **289.87 μs** |  **2.000** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 253.91 μs |  3.713 μs |  6.882 μs | 249.77 μs |  2.000 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **572.86 μs** | **14.963 μs** | **26.206 μs** | **554.16 μs** |  **3.120** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 515.73 μs |  3.877 μs |  6.891 μs | 512.39 μs |  2.000 | 12.6953 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **446.74 μs** | **16.583 μs** | **31.550 μs** | **466.13 μs** |  **3.000** |  **4.8828** |      **-** |   **94241 B** |
| Warm   | DocumentLookup     | 414.59 μs | 17.263 μs | 31.128 μs | 400.78 μs |  3.154 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **81.03 μs** |  **0.269 μs** |  **0.499 μs** |  **80.90 μs** |  **2.000** |  **3.4180** | **0.2441** |   **58457 B** |
| Warm   | InterpreterControl |  43.65 μs |  0.612 μs |  1.104 μs |  43.15 μs |  2.000 |       - |      - |     672 B |
