```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,117.72 μs** | **11.974 μs** | **34.162 μs** | **1,103.28 μs** |  **2.000** | **31.2500** |       **-** |  **584486 B** |
| Warm   | NodeRead           |   691.26 μs |  6.638 μs | 11.970 μs |   683.73 μs |  2.000 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,227.11 μs** | **15.024 μs** | **30.005 μs** | **1,226.37 μs** |  **2.000** | **31.2500** |       **-** |  **615478 B** |
| Warm   | ElementReadWrite   |   757.48 μs |  4.761 μs |  8.825 μs |   753.42 μs |  2.000 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,434.47 μs** | **21.989 μs** | **39.086 μs** | **1,411.31 μs** |  **2.923** | **41.0156** | **13.6719** |  **713594 B** |
| Warm   | DocumentLookup     | 1,036.49 μs | 19.299 μs | 33.801 μs | 1,049.12 μs |  3.083 | 23.4375 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **420.79 μs** |  **2.246 μs** |  **4.106 μs** |   **419.38 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    46.02 μs |  1.006 μs |  1.839 μs |    44.85 μs |  2.897 |       - |       - |     624 B |
