```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.74GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,105.43 μs** | **13.053 μs** | **29.463 μs** | **1,094.56 μs** |  **2.000** | **33.2031** |  **9.7656** |  **584422 B** |
| Warm   | NodeRead           |   713.21 μs | 21.591 μs | 40.021 μs |   707.34 μs |  4.000 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,180.14 μs** | **10.858 μs** | **18.730 μs** | **1,170.76 μs** |  **2.000** | **31.2500** |       **-** |  **615478 B** |
| Warm   | ElementReadWrite   |   766.36 μs |  1.488 μs |  2.606 μs |   766.70 μs |  2.000 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,407.55 μs** | **26.875 μs** | **50.477 μs** | **1,396.03 μs** |  **3.647** | **41.0156** | **13.6719** |  **713594 B** |
| Warm   | DocumentLookup     | 1,027.10 μs | 31.096 μs | 54.461 μs | 1,003.06 μs |  3.120 | 23.4375 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **421.25 μs** |  **2.378 μs** |  **4.348 μs** |   **420.67 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    44.67 μs |  0.094 μs |  0.165 μs |    44.63 μs |  2.000 |       - |       - |     624 B |
