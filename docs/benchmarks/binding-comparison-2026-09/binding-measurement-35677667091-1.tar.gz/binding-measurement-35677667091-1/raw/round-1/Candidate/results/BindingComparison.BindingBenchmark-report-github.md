```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error     | StdDev    | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|----------:|----------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **291.68 μs** |  **5.998 μs** | **10.662 μs** | **285.28 μs** |  **2.963** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 259.84 μs |  2.783 μs |  5.018 μs | 260.41 μs |  2.000 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **566.48 μs** |  **5.743 μs** | **10.356 μs** | **567.19 μs** |  **2.000** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 541.77 μs | 11.724 μs | 21.140 μs | 543.54 μs |  4.000 | 12.6953 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **450.85 μs** | **32.294 μs** | **60.655 μs** | **410.60 μs** |  **2.933** |  **4.8828** |      **-** |   **94241 B** |
| Warm   | DocumentLookup     | 422.75 μs | 21.637 μs | 38.459 μs | 430.58 μs |  3.714 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **82.94 μs** |  **0.254 μs** |  **0.445 μs** |  **82.92 μs** |  **2.000** |  **3.4180** | **0.2441** |   **58457 B** |
| Warm   | InterpreterControl |  43.58 μs |  0.311 μs |  0.561 μs |  43.31 μs |  2.000 |       - |      - |     672 B |
