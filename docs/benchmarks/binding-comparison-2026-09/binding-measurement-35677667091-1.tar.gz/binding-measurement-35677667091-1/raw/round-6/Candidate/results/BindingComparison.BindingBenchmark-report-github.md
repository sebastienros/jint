```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error    | StdDev    | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|---------:|----------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **299.81 μs** | **8.660 μs** | **15.393 μs** | **289.70 μs** |  **3.200** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 256.55 μs | 2.217 μs |  4.053 μs | 256.39 μs |  2.000 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **561.46 μs** | **6.572 μs** | **11.336 μs** | **565.97 μs** |  **2.000** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 526.60 μs | 2.182 μs |  3.935 μs | 527.46 μs |  2.000 | 12.6953 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **407.86 μs** | **6.639 μs** | **12.305 μs** | **403.43 μs** |  **2.000** |  **4.8828** |      **-** |   **94241 B** |
| Warm   | DocumentLookup     | 380.70 μs | 5.764 μs | 10.246 μs | 381.90 μs |  2.000 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **83.03 μs** | **0.375 μs** |  **0.656 μs** |  **83.05 μs** |  **2.000** |  **3.4180** | **0.2441** |   **58457 B** |
| Warm   | InterpreterControl |  43.40 μs | 0.305 μs |  0.542 μs |  43.19 μs |  2.000 |       - |      - |     672 B |
