```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,127.98 μs** | **15.902 μs** | **38.707 μs** | **1,114.08 μs** |  **2.000** | **31.2500** |       **-** |  **584486 B** |
| Warm   | NodeRead           |   695.86 μs | 13.161 μs | 23.394 μs |   692.45 μs |  2.000 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,184.49 μs** |  **7.417 μs** | **13.562 μs** | **1,179.69 μs** |  **2.000** | **35.1563** | **11.7188** |  **615681 B** |
| Warm   | ElementReadWrite   |   790.72 μs | 11.904 μs | 22.064 μs |   777.81 μs |  2.000 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,436.21 μs** | **21.077 μs** | **38.006 μs** | **1,416.11 μs** |  **2.692** | **41.0156** | **13.6719** |  **713594 B** |
| Warm   | DocumentLookup     | 1,007.00 μs | 14.026 μs | 25.997 μs | 1,015.19 μs |  2.000 | 23.4375 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **427.39 μs** |  **2.247 μs** |  **3.994 μs** |   **427.99 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    44.78 μs |  0.144 μs |  0.248 μs |    44.90 μs |  2.000 |       - |       - |     624 B |
