```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error     | StdDev    | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|----------:|----------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **295.96 μs** |  **7.566 μs** | **12.848 μs** | **292.52 μs** |  **3.600** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 293.13 μs | 20.573 μs | 37.618 μs | 268.70 μs |  3.000 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **537.63 μs** |  **8.726 μs** | **16.173 μs** | **527.95 μs** |  **3.071** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 539.01 μs |  2.355 μs |  4.306 μs | 541.05 μs |  2.000 | 12.6953 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **410.25 μs** |  **2.743 μs** |  **5.084 μs** | **409.81 μs** |  **2.000** |  **4.8828** |      **-** |   **94241 B** |
| Warm   | DocumentLookup     | 408.10 μs |  5.539 μs |  9.845 μs | 411.84 μs |  2.000 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **83.40 μs** |  **0.488 μs** |  **0.868 μs** |  **83.02 μs** |  **2.000** |  **3.4180** | **0.2441** |   **58457 B** |
| Warm   | InterpreterControl |  43.35 μs |  0.299 μs |  0.531 μs |  43.11 μs |  2.000 |       - |      - |     672 B |
