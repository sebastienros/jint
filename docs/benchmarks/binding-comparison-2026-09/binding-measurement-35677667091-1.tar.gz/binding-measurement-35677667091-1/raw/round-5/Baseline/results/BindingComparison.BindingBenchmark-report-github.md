```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,123.93 μs** | **13.952 μs** | **35.260 μs** | **1,119.67 μs** |  **2.000** | **31.2500** |       **-** |  **584486 B** |
| Warm   | NodeRead           |   694.38 μs | 27.263 μs | 49.161 μs |   674.41 μs |  2.929 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,192.10 μs** | **13.772 μs** | **25.528 μs** | **1,186.95 μs** |  **2.000** | **35.1563** | **11.7188** |  **615681 B** |
| Warm   | ElementReadWrite   |   809.08 μs | 32.849 μs | 59.234 μs |   771.44 μs |  3.037 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,467.05 μs** | **30.971 μs** | **57.406 μs** | **1,461.54 μs** |  **4.000** | **41.0156** | **13.6719** |  **713594 B** |
| Warm   | DocumentLookup     | 1,030.64 μs |  3.947 μs |  7.016 μs | 1,034.36 μs |  2.000 | 23.4375 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **422.79 μs** |  **3.613 μs** |  **6.786 μs** |   **424.98 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    44.63 μs |  0.025 μs |  0.042 μs |    44.62 μs |  2.000 |       - |       - |     624 B |
