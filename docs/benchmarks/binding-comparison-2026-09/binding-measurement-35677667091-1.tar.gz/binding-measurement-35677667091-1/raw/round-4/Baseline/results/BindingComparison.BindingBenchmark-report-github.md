```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,147.33 μs** | **22.986 μs** | **54.182 μs** | **1,157.76 μs** |  **3.840** | **33.2031** |  **9.7656** |  **584422 B** |
| Warm   | NodeRead           |   660.52 μs |  6.428 μs | 11.916 μs |   666.67 μs |  2.000 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,203.53 μs** | **13.840 μs** | **31.800 μs** | **1,190.77 μs** |  **2.000** | **31.2500** |       **-** |  **615734 B** |
| Warm   | ElementReadWrite   |   751.17 μs | 11.162 μs | 20.690 μs |   751.00 μs |  2.000 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,371.12 μs** |  **5.768 μs** | **10.834 μs** | **1,369.52 μs** |  **2.000** | **41.0156** | **13.6719** |  **713274 B** |
| Warm   | DocumentLookup     | 1,012.69 μs | 23.644 μs | 44.986 μs | 1,038.38 μs |  3.000 | 23.4375 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **416.88 μs** |  **2.905 μs** |  **5.528 μs** |   **415.85 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    44.97 μs |  0.136 μs |  0.253 μs |    44.95 μs |  2.000 |       - |       - |     624 B |
