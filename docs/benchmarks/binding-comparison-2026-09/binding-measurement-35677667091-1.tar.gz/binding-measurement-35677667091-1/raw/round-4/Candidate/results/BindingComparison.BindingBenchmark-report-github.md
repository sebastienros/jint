```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error     | StdDev    | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|----------:|----------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **319.40 μs** | **24.599 μs** | **44.356 μs** | **288.97 μs** |  **3.037** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 251.86 μs |  1.984 μs |  3.726 μs | 253.78 μs |  2.000 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **552.83 μs** |  **5.550 μs** | **10.008 μs** | **548.83 μs** |  **2.000** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 519.69 μs | 10.924 μs | 19.975 μs | 521.08 μs |  3.867 | 12.6953 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **418.62 μs** |  **0.773 μs** |  **1.432 μs** | **418.46 μs** |  **2.000** |  **4.8828** |      **-** |   **94241 B** |
| Warm   | DocumentLookup     | 418.03 μs | 23.173 μs | 42.952 μs | 409.88 μs |  3.867 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **82.87 μs** |  **0.252 μs** |  **0.454 μs** |  **82.85 μs** |  **2.000** |  **3.4180** | **0.2441** |   **58457 B** |
| Warm   | InterpreterControl |  43.72 μs |  0.635 μs |  1.112 μs |  43.28 μs |  2.000 |       - |      - |     672 B |
