```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error    | StdDev   | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|---------:|---------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **271.11 μs** | **0.473 μs** | **0.828 μs** | **271.40 μs** |  **2.000** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 251.21 μs | 1.417 μs | 2.556 μs | 250.02 μs |  2.000 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **470.03 μs** | **1.338 μs** | **2.480 μs** | **469.58 μs** |  **2.000** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 445.41 μs | 2.753 μs | 5.102 μs | 446.72 μs |  2.000 | 13.1836 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **380.48 μs** | **0.787 μs** | **1.478 μs** | **380.89 μs** |  **2.000** |  **5.3711** | **0.4883** |   **94241 B** |
| Warm   | DocumentLookup     | 359.53 μs | 3.475 μs | 6.612 μs | 357.04 μs |  2.000 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **74.86 μs** | **0.228 μs** | **0.405 μs** |  **74.79 μs** |  **2.000** |  **3.4180** | **0.2441** |   **58457 B** |
| Warm   | InterpreterControl |  47.30 μs | 0.333 μs | 0.592 μs |  46.98 μs |  2.000 |       - |      - |     672 B |
