```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,056.47 μs** | **10.086 μs** | **29.421 μs** | **1,049.55 μs** |  **2.000** | **31.2500** |       **-** |  **584230 B** |
| Warm   | NodeRead           |   646.76 μs |  5.652 μs | 10.336 μs |   648.23 μs |  2.000 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,093.46 μs** | **11.159 μs** | **20.122 μs** | **1,091.67 μs** |  **2.000** | **31.2500** |       **-** |  **615734 B** |
| Warm   | ElementReadWrite   |   673.85 μs |  7.153 μs | 13.435 μs |   670.97 μs |  2.000 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,279.00 μs** |  **8.727 μs** | **15.737 μs** | **1,275.08 μs** |  **2.000** | **41.0156** | **13.6719** |  **713594 B** |
| Warm   | DocumentLookup     |   905.59 μs |  2.618 μs |  4.917 μs |   905.73 μs |  2.000 | 24.4141 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **390.89 μs** |  **1.140 μs** |  **2.026 μs** |   **390.48 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    47.77 μs |  0.428 μs |  0.761 μs |    47.78 μs |  2.000 |       - |       - |     624 B |
