```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,080.18 μs** | **14.671 μs** | **38.391 μs** | **1,061.80 μs** |  **2.453** | **31.2500** |       **-** |  **584486 B** |
| Warm   | NodeRead           |   667.95 μs | 10.334 μs | 18.634 μs |   658.53 μs |  3.037 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,103.42 μs** | **12.402 μs** | **29.234 μs** | **1,092.40 μs** |  **2.085** | **31.2500** |       **-** |  **615734 B** |
| Warm   | ElementReadWrite   |   682.29 μs |  9.508 μs | 17.386 μs |   671.68 μs |  2.000 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,305.16 μs** |  **8.142 μs** | **14.888 μs** | **1,309.53 μs** |  **2.000** | **41.0156** | **13.6719** |  **713274 B** |
| Warm   | DocumentLookup     |   893.11 μs |  5.151 μs |  9.801 μs |   897.94 μs |  2.000 | 24.4141 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **395.49 μs** |  **2.231 μs** |  **4.244 μs** |   **394.89 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    48.49 μs |  0.399 μs |  0.689 μs |    48.60 μs |  2.000 |       - |       - |     624 B |
