```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error    | StdDev   | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|---------:|---------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **273.91 μs** | **1.755 μs** | **3.210 μs** | **272.61 μs** |  **2.000** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 253.82 μs | 1.761 μs | 3.265 μs | 253.40 μs |  2.000 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **484.26 μs** | **2.539 μs** | **4.578 μs** | **483.77 μs** |  **2.000** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 445.22 μs | 1.491 μs | 2.800 μs | 444.38 μs |  2.000 | 13.1836 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **384.97 μs** | **5.107 μs** | **8.945 μs** | **380.01 μs** |  **2.000** |  **4.8828** |      **-** |   **94241 B** |
| Warm   | DocumentLookup     | 355.55 μs | 1.501 μs | 2.744 μs | 356.31 μs |  2.000 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **74.73 μs** | **0.331 μs** | **0.579 μs** |  **74.91 μs** |  **2.000** |  **3.4180** | **0.2441** |   **58457 B** |
| Warm   | InterpreterControl |  46.86 μs | 0.080 μs | 0.138 μs |  46.84 μs |  2.000 |       - |      - |     672 B |
