```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error    | StdDev   | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|---------:|---------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **273.59 μs** | **2.987 μs** | **6.366 μs** | **270.67 μs** |  **2.000** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 256.32 μs | 4.411 μs | 8.285 μs | 251.57 μs |  2.933 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **478.22 μs** | **1.601 μs** | **3.047 μs** | **479.63 μs** |  **2.000** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 443.06 μs | 1.691 μs | 3.134 μs | 443.93 μs |  2.000 | 13.1836 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **374.82 μs** | **2.460 μs** | **4.372 μs** | **373.56 μs** |  **2.000** |  **4.8828** |      **-** |   **94241 B** |
| Warm   | DocumentLookup     | 352.88 μs | 1.206 μs | 2.295 μs | 353.56 μs |  2.000 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **72.69 μs** | **0.402 μs** | **0.725 μs** |  **72.39 μs** |  **2.000** |  **3.4180** | **0.3662** |   **58497 B** |
| Warm   | InterpreterControl |  46.85 μs | 0.094 μs | 0.165 μs |  46.88 μs |  2.000 |       - |      - |     672 B |
