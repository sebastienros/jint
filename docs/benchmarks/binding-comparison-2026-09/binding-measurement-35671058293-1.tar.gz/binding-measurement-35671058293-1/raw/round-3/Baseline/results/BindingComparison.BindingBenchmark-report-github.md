```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,046.21 μs** | **10.060 μs** | **33.785 μs** | **1,029.75 μs** |  **2.205** | **31.2500** |       **-** |  **584230 B** |
| Warm   | NodeRead           |   667.06 μs |  4.126 μs |  7.544 μs |   667.52 μs |  2.000 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,101.17 μs** | **14.013 μs** | **32.196 μs** | **1,089.19 μs** |  **2.000** | **31.2500** |       **-** |  **615734 B** |
| Warm   | ElementReadWrite   |   689.91 μs |  6.238 μs | 11.089 μs |   689.04 μs |  2.000 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,331.51 μs** |  **8.044 μs** | **14.710 μs** | **1,329.41 μs** |  **2.000** | **41.0156** | **13.6719** |  **713594 B** |
| Warm   | DocumentLookup     |   902.80 μs |  6.668 μs | 12.359 μs |   905.78 μs |  2.000 | 24.4141 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **394.35 μs** |  **3.483 μs** |  **6.281 μs** |   **392.52 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    48.63 μs |  0.118 μs |  0.213 μs |    48.56 μs |  2.000 |       - |       - |     624 B |
