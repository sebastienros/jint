```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,059.28 μs** | **12.493 μs** | **30.409 μs** | **1,049.33 μs** |  **2.000** | **31.2500** |       **-** |  **584230 B** |
| Warm   | NodeRead           |   647.81 μs |  5.705 μs | 10.716 μs |   649.79 μs |  2.000 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,117.17 μs** | **12.106 μs** | **29.468 μs** | **1,112.17 μs** |  **2.000** | **31.2500** |       **-** |  **615734 B** |
| Warm   | ElementReadWrite   |   705.00 μs | 22.461 μs | 41.633 μs |   678.10 μs |  3.071 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,312.43 μs** |  **5.620 μs** |  **9.990 μs** | **1,308.95 μs** |  **2.000** | **41.0156** | **13.6719** |  **713274 B** |
| Warm   | DocumentLookup     |   914.44 μs |  1.539 μs |  2.890 μs |   914.38 μs |  2.000 | 24.4141 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **398.61 μs** |  **2.383 μs** |  **4.298 μs** |   **397.60 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    47.66 μs |  0.182 μs |  0.323 μs |    47.59 μs |  2.000 |       - |       - |     624 B |
