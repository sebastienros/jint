```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.87GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error    | StdDev   | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|---------:|---------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **273.30 μs** | **1.141 μs** | **2.143 μs** | **273.65 μs** |  **2.000** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 250.29 μs | 0.727 μs | 1.366 μs | 250.48 μs |  2.000 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **471.23 μs** | **2.244 μs** | **4.269 μs** | **471.25 μs** |  **2.000** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 437.94 μs | 1.850 μs | 3.335 μs | 436.16 μs |  2.000 | 13.1836 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **385.01 μs** | **3.631 μs** | **6.454 μs** | **388.15 μs** |  **2.000** |  **4.8828** |      **-** |   **94241 B** |
| Warm   | DocumentLookup     | 359.40 μs | 1.091 μs | 2.022 μs | 358.96 μs |  2.000 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **72.51 μs** | **0.395 μs** | **0.733 μs** |  **72.32 μs** |  **2.000** |  **3.4180** | **0.2441** |   **58457 B** |
| Warm   | InterpreterControl |  47.72 μs | 0.467 μs | 0.842 μs |  47.51 μs |  2.000 |       - |      - |     672 B |
