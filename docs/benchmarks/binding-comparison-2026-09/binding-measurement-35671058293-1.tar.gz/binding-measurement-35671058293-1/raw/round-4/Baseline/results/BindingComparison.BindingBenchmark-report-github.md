```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,044.61 μs** |  **8.218 μs** | **19.847 μs** | **1,037.77 μs** |  **2.000** | **31.2500** |       **-** |  **584486 B** |
| Warm   | NodeRead           |   652.29 μs |  3.842 μs |  6.828 μs |   649.86 μs |  2.000 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,092.73 μs** | **11.429 μs** | **28.250 μs** | **1,084.16 μs** |  **2.000** | **31.2500** |       **-** |  **615734 B** |
| Warm   | ElementReadWrite   |   680.68 μs |  5.033 μs |  9.076 μs |   684.86 μs |  2.000 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,293.53 μs** |  **4.629 μs** |  **8.694 μs** | **1,289.85 μs** |  **2.000** | **41.0156** | **13.6719** |  **713274 B** |
| Warm   | DocumentLookup     |   897.33 μs |  3.565 μs |  6.609 μs |   895.38 μs |  2.000 | 24.4141 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **390.41 μs** |  **2.454 μs** |  **4.425 μs** |   **390.18 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    47.90 μs |  0.171 μs |  0.291 μs |    47.77 μs |  2.000 |       - |       - |     624 B |
