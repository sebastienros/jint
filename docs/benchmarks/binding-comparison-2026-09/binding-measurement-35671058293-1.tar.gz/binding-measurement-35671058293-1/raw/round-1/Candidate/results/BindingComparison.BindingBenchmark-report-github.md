```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean      | Error    | StdDev   | Median    | MValue | Gen0    | Gen1   | Allocated |
|------- |------------------- |----------:|---------:|---------:|----------:|-------:|--------:|-------:|----------:|
| **Cold**   | **NodeRead**           | **273.17 μs** | **0.800 μs** | **1.442 μs** | **273.63 μs** |  **2.000** |  **5.3711** | **0.4883** |   **94865 B** |
| Warm   | NodeRead           | 253.11 μs | 0.952 μs | 1.788 μs | 253.59 μs |  2.000 |  1.9531 |      - |   32816 B |
| **Cold**   | **ElementReadWrite**   | **478.89 μs** | **2.337 μs** | **4.331 μs** | **477.31 μs** |  **2.000** | **16.6016** | **1.9531** |  **286572 B** |
| Warm   | ElementReadWrite   | 446.84 μs | 5.154 μs | 9.424 μs | 441.13 μs |  2.000 | 13.1836 |      - |  224728 B |
| **Cold**   | **DocumentLookup**     | **379.17 μs** | **0.711 μs** | **1.300 μs** | **379.03 μs** |  **2.000** |  **4.8828** |      **-** |   **94241 B** |
| Warm   | DocumentLookup     | 354.28 μs | 1.133 μs | 2.157 μs | 353.57 μs |  2.000 |  1.9531 |      - |   32840 B |
| **Cold**   | **InterpreterControl** |  **74.18 μs** | **0.356 μs** | **0.678 μs** |  **74.13 μs** |  **2.000** |  **3.4180** | **0.2441** |   **58457 B** |
| Warm   | InterpreterControl |  46.60 μs | 0.046 μs | 0.080 μs |  46.59 μs |  2.000 |       - |      - |     672 B |
