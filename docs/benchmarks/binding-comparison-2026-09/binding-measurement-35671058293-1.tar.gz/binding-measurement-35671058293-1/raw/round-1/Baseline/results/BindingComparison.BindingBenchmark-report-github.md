```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3
  Job-GHXJKN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v3

AnalyzeLaunchVariance=True  Concurrent=False  LaunchCount=3  

```
| Method | Workload           | Mean        | Error     | StdDev    | Median      | MValue | Gen0    | Gen1    | Allocated |
|------- |------------------- |------------:|----------:|----------:|------------:|-------:|--------:|--------:|----------:|
| **Cold**   | **NodeRead**           | **1,047.98 μs** |  **5.864 μs** | **11.299 μs** | **1,050.07 μs** |  **2.000** | **31.2500** |       **-** |  **584486 B** |
| Warm   | NodeRead           |   671.14 μs |  3.450 μs |  6.395 μs |   670.64 μs |  2.000 | 16.6016 |       - |  288840 B |
| **Cold**   | **ElementReadWrite**   | **1,108.03 μs** | **15.278 μs** | **36.605 μs** | **1,097.00 μs** |  **2.000** | **31.2500** |       **-** |  **615478 B** |
| Warm   | ElementReadWrite   |   691.66 μs |  5.824 μs | 10.796 μs |   692.79 μs |  2.000 | 18.5547 |       - |  320808 B |
| **Cold**   | **DocumentLookup**     | **1,309.71 μs** |  **9.073 μs** | **16.817 μs** | **1,308.70 μs** |  **2.000** | **41.0156** | **13.6719** |  **713594 B** |
| Warm   | DocumentLookup     |   912.04 μs |  4.416 μs |  8.186 μs |   911.02 μs |  2.000 | 24.4141 |       - |  416808 B |
| **Cold**   | **InterpreterControl** |   **399.39 μs** |  **1.846 μs** |  **3.467 μs** |   **398.51 μs** |  **2.000** | **15.6250** |  **3.9063** |  **282311 B** |
| Warm   | InterpreterControl |    48.96 μs |  0.099 μs |  0.171 μs |    48.89 μs |  2.000 |       - |       - |     624 B |
